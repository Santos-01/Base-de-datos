﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Telefonos
{
    public partial class Form1 : Form
    {
        public void Buscar() 
        {
            string Nombre = "", casa = "", oficina = "", celular = "";
            int cantError = 0;
            int Cantidad = 0;

            Base_de_datos BaseD = new Base_de_datos();
            cantError = BaseD.Buscar(ref Cantidad, txtNombre.Text, ref casa, ref oficina, ref celular);
            if (cantError < 0) 
            {
                MessageBox.Show("Error");
                txtNombre.Clear();
                txtCasa.Clear();
                txtOficina.Clear();
                txtCelular.Clear();
                txtNombre.Focus();
            }
            else if (Cantidad > 0)
            {
                txtCasa.Text = casa;
                txtOficina.Text = oficina;
                txtCelular.Text = celular;
                cmdCancelar.Focus();
            }
            else 
            {
                txtNombre.Focus();
            }

        }
        public void ConectaBaseDatos() 
        {
            Base_de_datos BaseD = new Base_de_datos();
            BaseD.Conecta();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void nombreDeContactoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gpbContacto.Visible= false;
            gpbNombres.Location = new Point(12, 42);
            gpbNombres.Visible = true;

        }

        private void CT_Click(object sender, EventArgs e)
        {
            gpbNombres.Visible= false;
            gpbContacto.Location = new Point(12, 42);
            gpbContacto.Visible = true;
        }

        private void cmdBuscar_Click(object sender, EventArgs e)
        {
            Buscar();
        }

        private void cmdCancelar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtCasa.Clear();
            txtOficina.Clear();
            txtCelular.Clear();
            txtNombre.Focus();
        }
    }
}
