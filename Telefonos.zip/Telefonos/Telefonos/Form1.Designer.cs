﻿namespace Telefonos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpbNombres = new System.Windows.Forms.GroupBox();
            this.lblMiguel = new System.Windows.Forms.Label();
            this.lblJuan = new System.Windows.Forms.Label();
            this.gpbContacto = new System.Windows.Forms.GroupBox();
            this.cmdCancelar = new System.Windows.Forms.Button();
            this.lblCelular = new System.Windows.Forms.Label();
            this.lblOficina = new System.Windows.Forms.Label();
            this.lblCasa = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.txtOficina = new System.Windows.Forms.TextBox();
            this.txtCasa = new System.Windows.Forms.TextBox();
            this.cmdBuscar = new System.Windows.Forms.Button();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.NM = new System.Windows.Forms.ToolStripMenuItem();
            this.CT = new System.Windows.Forms.ToolStripMenuItem();
            this.cmdAltas = new System.Windows.Forms.Button();
            this.gpbNombres.SuspendLayout();
            this.gpbContacto.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpbNombres
            // 
            this.gpbNombres.Controls.Add(this.lblMiguel);
            this.gpbNombres.Controls.Add(this.lblJuan);
            this.gpbNombres.Location = new System.Drawing.Point(12, 27);
            this.gpbNombres.Name = "gpbNombres";
            this.gpbNombres.Size = new System.Drawing.Size(163, 298);
            this.gpbNombres.TabIndex = 1;
            this.gpbNombres.TabStop = false;
            this.gpbNombres.Text = "Nombres";
            this.gpbNombres.Visible = false;
            // 
            // lblMiguel
            // 
            this.lblMiguel.AutoSize = true;
            this.lblMiguel.Location = new System.Drawing.Point(15, 65);
            this.lblMiguel.Name = "lblMiguel";
            this.lblMiguel.Size = new System.Drawing.Size(38, 13);
            this.lblMiguel.TabIndex = 1;
            this.lblMiguel.Text = "Miguel";
            // 
            // lblJuan
            // 
            this.lblJuan.AutoSize = true;
            this.lblJuan.Location = new System.Drawing.Point(15, 28);
            this.lblJuan.Name = "lblJuan";
            this.lblJuan.Size = new System.Drawing.Size(30, 13);
            this.lblJuan.TabIndex = 0;
            this.lblJuan.Text = "Juan";
            // 
            // gpbContacto
            // 
            this.gpbContacto.Controls.Add(this.cmdAltas);
            this.gpbContacto.Controls.Add(this.cmdCancelar);
            this.gpbContacto.Controls.Add(this.lblCelular);
            this.gpbContacto.Controls.Add(this.lblOficina);
            this.gpbContacto.Controls.Add(this.lblCasa);
            this.gpbContacto.Controls.Add(this.lblNombre);
            this.gpbContacto.Controls.Add(this.txtCelular);
            this.gpbContacto.Controls.Add(this.txtOficina);
            this.gpbContacto.Controls.Add(this.txtCasa);
            this.gpbContacto.Controls.Add(this.cmdBuscar);
            this.gpbContacto.Controls.Add(this.txtNombre);
            this.gpbContacto.Location = new System.Drawing.Point(181, 27);
            this.gpbContacto.Name = "gpbContacto";
            this.gpbContacto.Size = new System.Drawing.Size(413, 298);
            this.gpbContacto.TabIndex = 2;
            this.gpbContacto.TabStop = false;
            this.gpbContacto.Text = "Numeros de contacto";
            this.gpbContacto.Visible = false;
            // 
            // cmdCancelar
            // 
            this.cmdCancelar.Location = new System.Drawing.Point(265, 89);
            this.cmdCancelar.Name = "cmdCancelar";
            this.cmdCancelar.Size = new System.Drawing.Size(88, 22);
            this.cmdCancelar.TabIndex = 9;
            this.cmdCancelar.Text = "Cancelar";
            this.cmdCancelar.UseVisualStyleBackColor = true;
            this.cmdCancelar.Click += new System.EventHandler(this.cmdCancelar_Click);
            // 
            // lblCelular
            // 
            this.lblCelular.AutoSize = true;
            this.lblCelular.Location = new System.Drawing.Point(6, 133);
            this.lblCelular.Name = "lblCelular";
            this.lblCelular.Size = new System.Drawing.Size(83, 13);
            this.lblCelular.TabIndex = 8;
            this.lblCelular.Text = "Telefono celular";
            // 
            // lblOficina
            // 
            this.lblOficina.AutoSize = true;
            this.lblOficina.Location = new System.Drawing.Point(6, 94);
            this.lblOficina.Name = "lblOficina";
            this.lblOficina.Size = new System.Drawing.Size(83, 13);
            this.lblOficina.TabIndex = 7;
            this.lblOficina.Text = "Telefono oficina";
            // 
            // lblCasa
            // 
            this.lblCasa.AutoSize = true;
            this.lblCasa.Location = new System.Drawing.Point(6, 59);
            this.lblCasa.Name = "lblCasa";
            this.lblCasa.Size = new System.Drawing.Size(75, 13);
            this.lblCasa.TabIndex = 6;
            this.lblCasa.Text = "Telefono casa";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(6, 24);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(44, 13);
            this.lblNombre.TabIndex = 5;
            this.lblNombre.Text = "Nombre";
            // 
            // txtCelular
            // 
            this.txtCelular.Location = new System.Drawing.Point(95, 126);
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(126, 20);
            this.txtCelular.TabIndex = 4;
            // 
            // txtOficina
            // 
            this.txtOficina.Location = new System.Drawing.Point(95, 91);
            this.txtOficina.Name = "txtOficina";
            this.txtOficina.Size = new System.Drawing.Size(126, 20);
            this.txtOficina.TabIndex = 3;
            // 
            // txtCasa
            // 
            this.txtCasa.Location = new System.Drawing.Point(95, 56);
            this.txtCasa.Name = "txtCasa";
            this.txtCasa.Size = new System.Drawing.Size(126, 20);
            this.txtCasa.TabIndex = 2;
            // 
            // cmdBuscar
            // 
            this.cmdBuscar.Location = new System.Drawing.Point(265, 23);
            this.cmdBuscar.Name = "cmdBuscar";
            this.cmdBuscar.Size = new System.Drawing.Size(88, 22);
            this.cmdBuscar.TabIndex = 0;
            this.cmdBuscar.Text = "Buscar";
            this.cmdBuscar.UseVisualStyleBackColor = true;
            this.cmdBuscar.Click += new System.EventHandler(this.cmdBuscar_Click);
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(95, 19);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(126, 20);
            this.txtNombre.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NM,
            this.CT});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // NM
            // 
            this.NM.Name = "NM";
            this.NM.Size = new System.Drawing.Size(129, 20);
            this.NM.Text = "Nombre de contacto";
            this.NM.Click += new System.EventHandler(this.nombreDeContactoToolStripMenuItem_Click);
            // 
            // CT
            // 
            this.CT.Name = "CT";
            this.CT.Size = new System.Drawing.Size(68, 20);
            this.CT.Text = "Contacto";
            this.CT.Click += new System.EventHandler(this.CT_Click);
            // 
            // cmdAltas
            // 
            this.cmdAltas.Location = new System.Drawing.Point(265, 56);
            this.cmdAltas.Name = "cmdAltas";
            this.cmdAltas.Size = new System.Drawing.Size(88, 22);
            this.cmdAltas.TabIndex = 10;
            this.cmdAltas.Text = "Altas";
            this.cmdAltas.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gpbContacto);
            this.Controls.Add(this.gpbNombres);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.gpbNombres.ResumeLayout(false);
            this.gpbNombres.PerformLayout();
            this.gpbContacto.ResumeLayout(false);
            this.gpbContacto.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gpbNombres;
        private System.Windows.Forms.GroupBox gpbContacto;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem NM;
        private System.Windows.Forms.ToolStripMenuItem CT;
        private System.Windows.Forms.TextBox txtCelular;
        private System.Windows.Forms.TextBox txtOficina;
        private System.Windows.Forms.TextBox txtCasa;
        private System.Windows.Forms.Button cmdBuscar;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button cmdCancelar;
        private System.Windows.Forms.Label lblCelular;
        private System.Windows.Forms.Label lblOficina;
        private System.Windows.Forms.Label lblCasa;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblMiguel;
        private System.Windows.Forms.Label lblJuan;
        private System.Windows.Forms.Button cmdAltas;
    }
}

