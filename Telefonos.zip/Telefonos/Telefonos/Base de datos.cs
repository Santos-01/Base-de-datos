﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Telefonos
{
    internal class Base_de_datos
    {
        public OleDbConnection Conexion;
        public OleDbCommand Comando;
        public OleDbDataReader Lectura;
         
        public int Conecta()
        {
            int tipoError = 0;
            string SQL = "";
            string ruta = Directory.GetCurrentDirectory();
            //SQL = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\iÑaKi GS\\Desktop\\P\\Datos\\Directorio.mdb";

            SQL = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+ruta+ "\\Directorio.mdb";

            try
            {
                Conexion = new OleDbConnection(SQL);
                Conexion.Open();
            }
            catch
            {
                MessageBox.Show("Error de conexion");
                tipoError = 1;
            }
            return tipoError;
        }

        public int Buscar(ref int existe, string Nombre, ref string casa, ref string oficina, ref string celular) 
        {
            int Contador = 0;
            string SQL = "Select Nombre, Casa,Oficina,Celular from Directorio where Nombre = '" + Nombre + "'";
            if (Conecta() == 0) 
            {
                Comando = new OleDbCommand(SQL,Conexion);
                Lectura = Comando.ExecuteReader();
                while (Lectura.Read()) 
                {
                    Contador++;
                    Nombre = Lectura.GetValue(0).ToString();
                    casa = Lectura.GetValue(1).ToString();
                    oficina = Lectura.GetValue(2).ToString();
                    celular = Lectura.GetValue(3).ToString();

                }
                Lectura.Close();
                existe = Contador;
            }
            else 
            {
                existe = 0;
                Contador = -1;
            }
            return Contador;
        }
    }
}
