﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace Tienda
{
    public partial class Form1 : Form
    {
        public void Buscar() 
        {
            string Nombre = "", Precio = "";
            int cantError = 0;
            int Cantidad = 0;

            BaseDatos BaseD = new BaseDatos();
            cantError = BaseD.Buscar(ref Cantidad, txtClave.Text, ref Nombre, ref Precio);
            if (cantError < 0) 
            {
                MessageBox.Show("Error");
                txtClave.Clear();
                txtNombre.Clear();
                txtPrecio.Clear();
                txtClave.Focus();
            }
            else if (Cantidad > 0) 
            {
                txtNombre.Text = Nombre;
                txtPrecio.Text = Precio;
                cmdCancelar.Focus();
            }
            else 
            {
                txtNombre.Focus();
            }
        }
        public void ConectaBaseDatos() 
        {
            BaseDatos BaseD = new BaseDatos();
            BaseD.Conecta();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConectaBaseDatos();
        }

        private void cmdBuscar_Click(object sender, EventArgs e)
        {
            Buscar();
        }

        private void cmdCancelar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtPrecio.Clear();
            txtClave.Clear();
            txtClave.Focus();
        }
    }
}
