﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Web;

namespace Tienda
{
    internal class BaseDatos
    {
        public OleDbConnection Conexion;
        public OleDbCommand Comando;
        public OleDbDataReader Lectura;

        public int Conecta() 
        {
            int tipoError = 0;
            string SQL = "";

            SQL = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Base de datos\\tienda.accdb\"";

            try 
            {
                Conexion = new OleDbConnection(SQL);
                Conexion.Open();
            }
            catch 
            {
                MessageBox.Show("Error de conexion");
                tipoError = 1;
            }
            return tipoError;
        }

        public int Buscar(ref int existe, string Clave, ref string Nombre,ref string Precio) 
        {
            int Contador = 0;
            string SQL = "Select Nombre, Precio from Productos where CodigoArticulo = '" + Clave + "'";
            if (Conecta() == 0) 
            {
                Comando = new OleDbCommand(SQL,Conexion);
                Lectura = Comando.ExecuteReader();
                while (Lectura.Read()) 
                {
                    Contador++;
                    Nombre = Lectura.GetValue(0).ToString();
                    Precio = Lectura.GetValue(1).ToString();
                }
                Lectura.Close();
                existe = Contador;
            }
            else 
            {
                existe = 0;
                Contador = -1;
            }
            return Contador;
        }

    }
}
